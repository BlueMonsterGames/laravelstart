<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>

        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">

        <style>
           </style>
    </head>
    <body>
    <h1>My Very First Laravel Apllication</h1>
    <p>Hey My Very First Laravel Application</p>
    </body>
</html>
