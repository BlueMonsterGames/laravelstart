<?php $__env->startSection('title'); ?>
    Trending quotes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="quotes">
        <h1>Latest Quotes</h1>
        <article class="quote">
            <div class="delete"><a href="#">x</a></div>
            Quote Text
            <div class="info">Created By <a href="#">Roshan</a> on...</div>
        </article>
        Pagination
    </section>
    <section class="edit-quote">
        <h1>Add A Quote</h1>
        <form method="post" action="<?php echo e(route('create')); ?>">
            <div class="input-group">
                <label for="author">Your Name</label>
                <input type="text" name="author" id="author" placeholder="Your Name">
            </div>
            <div class="input-group">
                <label for="quote">Your Quote</label>
                <textarea name="quote" id="quote" rows="5" placeholder="Quote"></textarea>
            </div>
            <button type="submit" class="btn">Submit Button</button>
            <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
        </form>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>