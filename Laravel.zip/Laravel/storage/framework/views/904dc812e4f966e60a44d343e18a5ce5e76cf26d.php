<?php $__env->startSection('content'); ?>

    <div class="centered">
        <?php foreach($actions as $action): ?>
            <a href="<?php echo e(route('niceaction',['action' => lcfirst($action->name)])); ?>"><?php echo e($action->name); ?></a>
        <?php endforeach; ?>
        <br>
        <?php if(count($errors) > 0): ?>
            <div>
                <ul>
                    <?php foreach($errors->all() as $error): ?>
                        <?php echo e($error); ?>

                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
        <form action="<?php echo e(route('add_action')); ?>" method="post">
            <label for="name">Name Of Action:</label>
            <input type="text" name="name" id="name"/> &nbsp;&nbsp;&nbsp;
            <label for="niceness">Niceness:</label>
            <input type="text" name="niceness" id="niceness"/>
            <button type="submit">Do A Nice Action!</button>
            <input type="hidden" value="<?php echo e(Session::token()); ?>" name="_token">
        </form>
        <br><br>
        <br><br>
        <ul>
            <?php foreach($logged_actions as $logged_action): ?>
                <li><?php echo e($logged_action->nice_action->name); ?></li>

                <?php foreach($logged_action->nice_action->categories as $category): ?>
                    <?php echo e($category->name); ?>

                <?php endforeach; ?>
            <?php endforeach; ?>
        </ul>

            <?php echo e(dd($db)); ?>



    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>